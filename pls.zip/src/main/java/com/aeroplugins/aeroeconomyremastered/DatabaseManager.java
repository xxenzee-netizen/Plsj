package com.aeroplugins.aeroeconomyremastered;

import java.io.File;
import java.sql.*;
import java.util.*;

public class DatabaseManager {
    private Connection connection;

    public DatabaseManager(File dbFile) {
        try {
            Class.forName("org.sqlite.JDBC");
            connection = DriverManager.getConnection("jdbc:sqlite:" + dbFile.getAbsolutePath());
            try (Statement statement = connection.createStatement()) {
                statement.execute("CREATE TABLE IF NOT EXISTS aero_balances (uuid TEXT PRIMARY KEY, balance REAL);");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public double getBalance(UUID uuid, double defaultBalance) {
        try (PreparedStatement ps = connection.prepareStatement("SELECT balance FROM aero_balances WHERE uuid = ?")) {
            ps.setString(1, uuid.toString());
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getDouble("balance");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return defaultBalance;
    }

    public void setBalance(UUID uuid, double amount) {
        try (PreparedStatement ps = connection.prepareStatement(
                "INSERT INTO aero_balances (uuid, balance) VALUES (?, ?) ON CONFLICT(uuid) DO UPDATE SET balance = ?")) {
            ps.setString(1, uuid.toString());
            ps.setDouble(2, amount);
            ps.setDouble(3, amount);
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Map<String, Double> getTopBalances(int limit) {
        Map<String, Double> topMap = new LinkedHashMap<>();
        try (PreparedStatement ps = connection.prepareStatement("SELECT uuid, balance FROM aero_balances ORDER BY balance DESC LIMIT ?")) {
            ps.setInt(1, limit);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    topMap.put(rs.getString("uuid"), rs.getDouble("balance"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return topMap;
    }
    
    public void close() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
