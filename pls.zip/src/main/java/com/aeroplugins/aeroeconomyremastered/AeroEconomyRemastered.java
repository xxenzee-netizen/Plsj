package com.aeroplugins.aeroeconomyremastered;

import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.ChatColor;
import net.md_5.bungee.api.ChatMessageType;
import net.md_5.bungee.api.chat.TextComponent;

import java.io.File;

public class AeroEconomyRemastered extends JavaPlugin {
    
    private File messagesFile;
    private FileConfiguration messagesConfig;
    private DatabaseManager dbManager;
    
    @Override
    public void onEnable() {
        saveDefaultConfig();
        createMessagesConfig();
        
        // Initialize SQLite local database engine
        dbManager = new DatabaseManager(new File(getDataFolder(), "economy.db"));
        
        CommandHandler handler = new CommandHandler(this);
        getCommand("bal").setExecutor(handler);
        getCommand("pay").setExecutor(handler);
        getCommand("aeco").setExecutor(handler);
        getCommand("baltop").setExecutor(handler);
        getCommand("ecohelp").setExecutor(handler);
        
        // Action Bar Thread Loop
        if (getConfig().getBoolean("action-bar.enabled", false)) {
            long interval = getConfig().getLong("action-bar.refresh-interval", 40);
            getServer().getScheduler().runTaskTimerAsynchronously(this, () -> {
                String sym = getConfig().getString("currencies.default.symbol", "⛃");
                String name = getConfig().getString("currencies.default.name", "Coins");
                String format = getConfig().getString("action-bar.text", "&fYour Balance: &a%currency_symbol%%balance%");
                
                for (Player player : getServer().getOnlinePlayers()) {
                    double balance = getBalance(player.getUniqueId());
                    String formatted = ChatColor.translateAlternateColorCodes('&', format
                        .replace("%balance%", String.format("%,.2f", balance))
                        .replace("%currency_symbol%", sym)
                        .replace("%currency_name%", name));
                    player.spigot().sendMessage(ChatMessageType.ACTION_BAR, TextComponent.fromLegacyText(formatted));
                }
            }, 0L, interval);
        }
        
        getLogger().info("=======================================");
        getLogger().info(" AeroEconomyRemastered 1.0.0 Initialized");
        getLogger().info(" Developed cleanly by Aero's Creations ");
        getLogger().info("=======================================");
    }
    
    @Override
    public void onDisable() {
        if (dbManager != null) {
            dbManager.close();
        }
    }
    
    private void createMessagesConfig() {
        messagesFile = new File(getDataFolder(), "messages.yml");
        if (!messagesFile.exists()) {
            messagesFile.getParentFile().mkdirs();
            saveResource("messages.yml", false);
        }
        messagesConfig = YamlConfiguration.loadConfiguration(messagesFile);
    }
    
    public String getLang(String path) {
        String prefix = messagesConfig.getString("prefix", "&8[&b&lAero&3&lEco&8] &r");
        String message = messagesConfig.getString(path, "&c[Missing Message Path: " + path + "]");
        return ChatColor.translateAlternateColorCodes('&', message.replace("%prefix%", prefix));
    }
    
    public double getBalance(java.util.UUID uuid) {
        double def = getConfig().getDouble("currencies.default.start-balance", 1000.0);
        return dbManager.getBalance(uuid, def);
    }
    
    public void setBalance(java.util.UUID uuid, double amount) {
        dbManager.setBalance(uuid, amount);
    }
    
    public DatabaseManager getDbManager() {
        return this.dbManager;
    }
}
