package com.aeroplugins.aeroeconomyremastered;

import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import java.util.Map;
import java.util.UUID;

public class CommandHandler implements CommandExecutor {
    
    private final AeroEconomyRemastered plugin;
    
    public CommandHandler(AeroEconomyRemastered plugin) {
        this.plugin = plugin;
    }
    
    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        String sym = plugin.getConfig().getString("currencies.default.symbol", "⛃");
        String col = plugin.getConfig().getString("currencies.default.color", "&a");
        String name = plugin.getConfig().getString("currencies.default.name", "Coins");
        
        // Help Menu Implementation
        if (cmd.getName().equalsIgnoreCase("ecohelp")) {
            sender.sendMessage(plugin.getLang("help-header"));
            sendHelpLine(sender, "/bal [player]", "View your wallet status or target balance details.");
            sendHelpLine(sender, "/pay [player] [amount]", "Securely transfer cash to an active account.");
            sendHelpLine(sender, "/baltop", "Display total global rankings based on active net worth.");
            if (sender.hasPermission("aeroeco.admin")) {
                sendHelpLine(sender, "/aeco give [player] [amount]", "Admin command to add money.");
                sendHelpLine(sender, "/aeco take [player] [amount]", "Admin command to remove money.");
                sendHelpLine(sender, "/aeco set [player] [amount]", "Admin command to overwrite balance.");
            }
            sender.sendMessage(plugin.getLang("help-footer"));
            return true;
        }
        
        // Balance Command Logic
        if (cmd.getName().equalsIgnoreCase("bal")) {
            if (args.length == 0) {
                if (!(sender instanceof Player)) {
                    sender.sendMessage(plugin.getLang("player-only"));
                    return true;
                }
                Player p = (Player) sender;
                sender.sendMessage(plugin.getLang("balance-format-self")
                    .replace("%balance%", String.format("%,.2f", plugin.getBalance(p.getUniqueId())))
                    .replace("%currency_symbol%", sym)
                    .replace("%currency_color%", col)
                    .replace("%currency_name%", name));
                return true;
            } else {
                OfflinePlayer target = Bukkit.getOfflinePlayer(args[0]);
                if (target == null || (!target.hasPlayedBefore() && !target.isOnline())) {
                    sender.sendMessage(plugin.getLang("player-not-found"));
                    return true;
                }
                sender.sendMessage(plugin.getLang("balance-format-other")
                    .replace("%player%", target.getName() != null ? target.getName() : args[0])
                    .replace("%balance%", String.format("%,.2f", plugin.getBalance(target.getUniqueId())))
                    .replace("%currency_symbol%", sym)
                    .replace("%currency_color%", col));
                return true;
            }
        }
        
        // Pay Command Logic
        if (cmd.getName().equalsIgnoreCase("pay")) {
            if (!(sender instanceof Player)) {
                sender.sendMessage(plugin.getLang("player-only"));
                return true;
            }
            if (args.length < 2) {
                sender.sendMessage(plugin.getLang("invalid-amount"));
                return true;
            }
            Player p = (Player) sender;
            Player target = Bukkit.getPlayer(args[0]);
            if (target == null) {
                sender.sendMessage(plugin.getLang("player-not-found"));
                return true;
            }
            if (target.getUniqueId().equals(p.getUniqueId())) {
                sender.sendMessage("§cYou cannot pay yourself!");
                return true;
            }
            
            try {
                double amount = Double.parseDouble(args[1]);
                if (amount <= 0 || Double.isNaN(amount) || Double.isInfinite(amount)) {
                    sender.sendMessage(plugin.getLang("invalid-amount"));
                    return true;
                }
                
                double pBal = plugin.getBalance(p.getUniqueId());
                if (pBal < amount) {
                    sender.sendMessage(plugin.getLang("insufficient-funds"));
                    return true;
                }
                
                plugin.setBalance(p.getUniqueId(), pBal - amount);
                plugin.setBalance(target.getUniqueId(), plugin.getBalance(target.getUniqueId()) + amount);
                
                p.sendMessage(plugin.getLang("payment-sent").replace("%amount%", String.format("%,.2f", amount)).replace("%currency_symbol%", sym).replace("%currency_color%", col).replace("%player%", target.getName()));
                target.sendMessage(plugin.getLang("payment-received").replace("%amount%", String.format("%,.2f", amount)).replace("%currency_symbol%", sym).replace("%currency_color%", col).replace("%player%", p.getName()));
            } catch (NumberFormatException e) {
                sender.sendMessage(plugin.getLang("invalid-amount"));
            }
            return true;
        }
        
        // Admin Command Logic
        if (cmd.getName().equalsIgnoreCase("aeco")) {
            if (!sender.hasPermission("aeroeco.admin")) {
                sender.sendMessage(plugin.getLang("no-permission"));
                return true;
            }
            if (args.length < 3) {
                sender.sendMessage("§cUsage: /aeco [give|take|set] [player] [amount]");
                return true;
            }
            
            String action = args[0];
            OfflinePlayer target = Bukkit.getOfflinePlayer(args[1]);
            if (target == null || (!target.hasPlayedBefore() && !target.isOnline())) {
                sender.sendMessage(plugin.getLang("player-not-found"));
                return true;
            }
            
            try {
                double amount = Double.parseDouble(args[2]);
                if (amount < 0 || Double.isNaN(amount) || Double.isInfinite(amount)) {
                    sender.sendMessage(plugin.getLang("invalid-amount"));
                    return true;
                }
                double current = plugin.getBalance(target.getUniqueId());
                String tName = target.getName() != null ? target.getName() : args[1];
                
                if (action.equalsIgnoreCase("give")) {
                    plugin.setBalance(target.getUniqueId(), current + amount);
                    sender.sendMessage(plugin.getLang("admin-give").replace("%amount%", String.format("%,.2f", amount)).replace("%currency_symbol%", sym).replace("%currency_color%", col).replace("%player%", tName));
                } else if (action.equalsIgnoreCase("take")) {
                    plugin.setBalance(target.getUniqueId(), Math.max(0, current - amount));
                    sender.sendMessage(plugin.getLang("admin-take").replace("%amount%", String.format("%,.2f", amount)).replace("%currency_symbol%", sym).replace("%currency_color%", col).replace("%player%", tName));
                } else if (action.equalsIgnoreCase("set")) {
                    plugin.setBalance(target.getUniqueId(), amount);
                    sender.sendMessage(plugin.getLang("admin-set").replace("%amount%", String.format("%,.2f", amount)).replace("%currency_symbol%", sym).replace("%currency_color%", col).replace("%player%", tName));
                } else {
                    sender.sendMessage("§cUsage: /aeco [give|take|set] [player] [amount]");
                }
            } catch (NumberFormatException e) {
                sender.sendMessage(plugin.getLang("invalid-amount"));
            }
            return true;
        }
        
        // Leaderboard Command Logic
        if (cmd.getName().equalsIgnoreCase("baltop")) {
            sender.sendMessage(plugin.getLang("leaderboard-header"));
            int size = plugin.getConfig().getInt("leaderboard.size", 10);
            Map<String, Double> top = plugin.getDbManager().getTopBalances(size);
            
            int pos = 1;
            for (Map.Entry<String, Double> entry : top.entrySet()) {
                OfflinePlayer op = Bukkit.getOfflinePlayer(UUID.fromString(entry.getKey()));
                String nameStr = op.getName() != null ? op.getName() : "Unknown";
                sender.sendMessage(plugin.getLang("leaderboard-format")
                    .replace("%position%", String.valueOf(pos))
                    .replace("%player%", nameStr)
                    .replace("%balance%", String.format("%,.2f", entry.getValue()))
                    .replace("%currency_symbol%", sym));
                pos++;
            }
            sender.sendMessage(plugin.getLang("leaderboard-footer"));
            return true;
        }
        
        return false;
    }
    
    private void sendHelpLine(CommandSender sender, String command, String description) {
        sender.sendMessage(plugin.getLang("help-line")
            .replace("%command%", command)
            .replace("%description%", description));
    }
}
